# Pro Video App

## Structure
- `frontend/` -> deploy to Vercel
- `backend/` -> deploy as a Flask Web Service

## Backend
Build:
`pip install -r requirements.txt`

Start:
`gunicorn app:app`

Environment variable:
`YOUTUBE_API_KEY=YOUR_NEW_KEY`

## Frontend
Edit `frontend/index.html`:
`const API = "https://YOUR-BACKEND-URL.onrender.com";`

Replace the placeholder with your deployed Flask backend URL.

## Important
Do not commit API keys to GitHub. Rotate any key that has been publicly exposed.
Use video downloading only where you have the necessary rights/permission and in accordance with the platform's terms.
